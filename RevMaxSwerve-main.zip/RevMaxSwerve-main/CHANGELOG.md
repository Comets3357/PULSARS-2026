# MAXSwerve C++ Template Changelog

## [2023.1] - 2023-02-03

### Added

- Added a configurable rate limiting system to prevent excessive loads from causing premature wheel failure.

### Fixed

- Turning SPARK MAX not using the correct feedback device.

## [2023.0] - 2023-01-18

Initial release of MAXSwerve robot project.